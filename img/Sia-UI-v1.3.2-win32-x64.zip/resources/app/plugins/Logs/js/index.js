import ReactDOM from 'react-dom'
import { logsPlugin } from './main.js'

ReactDOM.render(logsPlugin(), document.getElementById('react-root'))
