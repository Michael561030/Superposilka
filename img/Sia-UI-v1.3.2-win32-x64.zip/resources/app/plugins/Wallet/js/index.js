import ReactDOM from 'react-dom'
import { initWallet } from './main.js'

ReactDOM.render(initWallet(), document.getElementById('react-root'))
