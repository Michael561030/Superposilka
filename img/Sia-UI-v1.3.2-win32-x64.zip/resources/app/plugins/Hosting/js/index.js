import ReactDOM from 'react-dom'
import { hostingPlugin } from './main.js'

ReactDOM.render(hostingPlugin(), document.getElementById('react-root'))

